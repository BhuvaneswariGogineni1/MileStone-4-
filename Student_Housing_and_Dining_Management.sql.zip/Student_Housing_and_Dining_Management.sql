-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 16, 2025 at 11:56 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Student_Housing_and_Dining_Management`
--

-- --------------------------------------------------------

--
-- Table structure for table `DietaryRestrictions`
--

CREATE TABLE `DietaryRestrictions` (
  `dietary_id` int(11) NOT NULL,
  `restriction_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Stand-in structure for view `dininghallinventory`
-- (See below for the actual view)
--
CREATE TABLE `dininghallinventory` (
`dining_hall_id` int(11)
,`DiningHallName` varchar(100)
,`food_item` varchar(100)
,`quantity` int(11)
,`expiration_date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `DiningHalls`
--

CREATE TABLE `DiningHalls` (
  `dining_hall_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `DiningHalls`
--

INSERT INTO `DiningHalls` (`dining_hall_id`, `name`, `location`, `capacity`) VALUES
(1, 'North Dining', 'North Campus', 200),
(2, 'South Dining', 'South Campus', 250),
(3, 'East Dining', 'East Campus', 180),
(4, 'West Dining', 'West Campus', 220),
(5, 'Central Dining', 'Central Campus', 300),
(6, 'Grand Dining', 'North Campus', 320),
(7, 'Riverside Dining', 'South Campus', 210),
(8, 'Mountain View Dining', 'East Campus', 230),
(9, 'Skyline Dining', 'West Campus', 270),
(10, 'Sunset Dining', 'Central Campus', 350),
(112, 'New Dining1', '113 Campus, University_1 ', 310),
(113, 'North Dining', 'North Campus', 200),
(114, 'South Dining', 'South Campus', 250),
(115, 'East Dining', 'East Campus', 180),
(116, 'West Dining', 'West Campus', 220),
(117, 'Central Dining', 'Central Campus', 300),
(118, 'Grand Dining', 'North Campus', 320),
(119, 'Riverside Dining', 'South Campus', 210),
(120, 'Mountain View Dining', 'East Campus', 230),
(121, 'Skyline Dining', 'West Campus', 270),
(122, 'Sunset Dining', 'Central Campus', 350),
(123, 'North Dining', 'North Campus', 200),
(124, 'South Dining', 'South Campus', 250),
(125, 'East Dining', 'East Campus', 180),
(126, 'West Dining', 'West Campus', 220),
(127, 'Central Dining', 'Central Campus', 300),
(128, 'Grand Dining', 'North Campus', 320),
(129, 'Riverside Dining', 'South Campus', 210),
(130, 'Mountain View Dining', 'East Campus', 230),
(131, 'Skyline Dining', 'West Campus', 270),
(132, 'Sunset Dining', 'Central Campus', 350);

-- --------------------------------------------------------

--
-- Stand-in structure for view `dininginventorystatus`
-- (See below for the actual view)
--
CREATE TABLE `dininginventorystatus` (
`dining_hall_id` int(11)
,`DiningHallName` varchar(100)
,`food_item` varchar(100)
,`quantity` int(11)
,`expiration_date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `DiningManagers`
--

CREATE TABLE `DiningManagers` (
  `manager_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `responsibilities` varchar(255) DEFAULT NULL,
  `assigned_dining_hall` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `DiningManagers`
--

INSERT INTO `DiningManagers` (`manager_id`, `name`, `responsibilities`, `assigned_dining_hall`) VALUES
(1, 'John Doe', 'Oversee kitchen staff', 1),
(2, 'Jane Smith', 'Manage food orders', 2),
(3, 'Chris Brown', 'Maintain inventory', 3),
(4, 'Emily White', 'Ensure quality control', 4),
(5, 'Mark Wilson', 'Manage dining services', 5),
(6, 'Laura Davis', 'Monitor safety protocols', 6),
(7, 'Steve Adams', 'Supervise meal plans', 7),
(8, 'Rachel Green', 'Oversee student satisfaction', 8),
(9, 'Monica Geller', 'Maintain cleanliness', 9),
(10, 'Ross Geller', 'Handle special requests', 10);

-- --------------------------------------------------------

--
-- Table structure for table `Dormitories`
--

CREATE TABLE `Dormitories` (
  `dormitory_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `capacity` int(11) NOT NULL,
  `location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Dormitories`
--

INSERT INTO `Dormitories` (`dormitory_id`, `name`, `capacity`, `location`) VALUES
(1, 'Dormitory A', 100, 'North Campus'),
(2, 'Dormitory B', 120, 'South Campus'),
(3, 'Dormitory C', 80, 'East Campus'),
(4, 'Dormitory D', 90, 'West Campus'),
(5, 'Dormitory E', 110, 'Central Campus'),
(6, 'Dormitory F', 130, 'North Campus'),
(7, 'Dormitory G', 70, 'South Campus'),
(8, 'Dormitory H', 95, 'East Campus'),
(9, 'Dormitory I', 85, 'West Campus'),
(10, 'Dormitory J', 115, 'Central Campus'),
(11, 'Dormitory A', 100, 'North Campus'),
(12, 'Dormitory B', 120, 'South Campus'),
(13, 'Dormitory C', 80, 'East Campus'),
(14, 'Dormitory D', 90, 'West Campus'),
(15, 'Dormitory E', 110, 'Central Campus'),
(16, 'Dormitory F', 130, 'North Campus'),
(17, 'Dormitory G', 70, 'South Campus'),
(18, 'Dormitory H', 95, 'East Campus'),
(19, 'Dormitory I', 85, 'West Campus'),
(20, 'Dormitory J', 115, 'Central Campus');

-- --------------------------------------------------------

--
-- Table structure for table `FoodSuppliers`
--

CREATE TABLE `FoodSuppliers` (
  `supplier_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact_info` varchar(255) NOT NULL,
  `food_items_supplied` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `FoodSuppliers`
--

INSERT INTO `FoodSuppliers` (`supplier_id`, `name`, `contact_info`, `food_items_supplied`) VALUES
(1, 'Supplier A', 'contactA@example.com', 'Rice, Bread, Eggs'),
(2, 'Supplier B', 'contactB@example.com', 'Milk, Cheese, Yogurt'),
(3, 'Supplier C', 'contactC@example.com', 'Fruits, Vegetables, Nuts'),
(4, 'Supplier D', 'contactD@example.com', 'Meat, Fish, Poultry'),
(5, 'Supplier E', 'contactE@example.com', 'Cereals, Pasta, Flour'),
(6, 'Supplier F', 'contactF@example.com', 'Seafood, Spices, Oils'),
(7, 'Supplier G', 'contactG@example.com', 'Tea, Coffee, Beverages'),
(8, 'Supplier H', 'contactH@example.com', 'Frozen Foods, Canned Goods'),
(9, 'Supplier I', 'contactI@example.com', 'Confectionery, Snacks, Sauces'),
(10, 'Supplier J', 'contactJ@example.com', 'Organic Produce, Specialty Items'),
(11, 'Supplier A', 'contactA@example.com', 'Rice, Bread, Eggs'),
(12, 'Supplier B', 'contactB@example.com', 'Milk, Cheese, Yogurt'),
(13, 'Supplier C', 'contactC@example.com', 'Fruits, Vegetables, Nuts'),
(14, 'Supplier D', 'contactD@example.com', 'Meat, Fish, Poultry'),
(15, 'Supplier E', 'contactE@example.com', 'Cereals, Pasta, Flour'),
(16, 'Supplier F', 'contactF@example.com', 'Seafood, Spices, Oils'),
(17, 'Supplier G', 'contactG@example.com', 'Tea, Coffee, Beverages'),
(18, 'Supplier H', 'contactH@example.com', 'Frozen Foods, Canned Goods'),
(19, 'Supplier I', 'contactI@example.com', 'Confectionery, Snacks, Sauces'),
(20, 'Supplier J', 'contactJ@example.com', 'Organic Produce, Specialty Items');

-- --------------------------------------------------------

--
-- Table structure for table `Inventory`
--

CREATE TABLE `Inventory` (
  `inventory_id` int(11) NOT NULL,
  `food_item` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `expiration_date` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `dining_hall_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Inventory`
--

INSERT INTO `Inventory` (`inventory_id`, `food_item`, `quantity`, `expiration_date`, `supplier_id`, `dining_hall_id`) VALUES
(11, 'Rice', 20, '2025-12-31', 1, 1),
(12, 'Bread', 80, '2025-11-30', 2, 2),
(13, 'Eggs', 200, '2025-10-15', 3, 3),
(14, 'Milk', 140, '2025-09-20', 4, 4),
(15, 'Cheese', 50, '2025-08-25', 5, 5),
(16, 'Vegetables', 90, '2025-07-18', 6, 6),
(17, 'Fruits', 120, '2025-06-10', 7, 7),
(18, 'Meat', 60, '2025-05-12', 8, 8),
(19, 'Fish', 75, '2025-04-05', 9, 9),
(20, 'Pasta', 110, '2025-03-28', 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `MealPlans`
--

CREATE TABLE `MealPlans` (
  `meal_plan_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `MealPlans`
--

INSERT INTO `MealPlans` (`meal_plan_id`, `type`, `description`, `cost`) VALUES
(1, 'Standard', 'Basic meal plan', '200.00'),
(2, 'Vegetarian', 'Vegetarian meal plan', '220.00'),
(3, 'Vegan', 'Vegan meal plan', '250.00'),
(4, 'Halal', 'Halal certified meals', '230.00'),
(5, 'Kosher', 'Kosher certified meals', '240.00'),
(6, 'Gluten-Free', 'Meals without gluten', '260.00'),
(7, 'Keto', 'Low carb meal plan', '270.00'),
(8, 'Paleo', 'Protein-rich meal plan', '280.00'),
(9, 'Mediterranean', 'Heart-healthy meals', '290.00'),
(11, 'Standard', 'Basic meal plan', '200.00'),
(12, 'Vegetarian', 'Vegetarian meal plan', '220.00'),
(13, 'Vegan', 'Vegan meal plan', '250.00'),
(14, 'Halal', 'Halal certified meals', '230.00'),
(15, 'Kosher', 'Kosher certified meals', '240.00'),
(16, 'Gluten-Free', 'Meals without gluten', '260.00'),
(17, 'Keto', 'Low carb meal plan', '270.00'),
(18, 'Paleo', 'Protein-rich meal plan', '280.00'),
(19, 'Mediterranean', 'Heart-healthy meals', '290.00'),
(20, 'Dairy-Free', 'Meals without dairy', '210.00'),
(21, 'High Protein', 'High protein meals for athletes', '300.00');

-- --------------------------------------------------------

--
-- Table structure for table `Roles`
--

CREATE TABLE `Roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Staff`
--

CREATE TABLE `Staff` (
  `staff_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL,
  `assigned_dining_hall` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Staff`
--

INSERT INTO `Staff` (`staff_id`, `name`, `role`, `assigned_dining_hall`) VALUES
(1, 'Michael Scott', 'Head Chef', 1),
(2, 'Jim Halpert', 'Sous Chef', 2),
(3, 'Pam Beesly', 'Nutritionist', 3),
(4, 'Dwight Schrute', 'Inventory Manager', 4),
(5, 'Angela Martin', 'Quality Control', 5),
(6, 'Stanley Hudson', 'Food Safety Officer', 6),
(7, 'Phyllis Vance', 'Kitchen Supervisor', 7),
(8, 'Ryan Howard', 'Procurement Officer', 8),
(9, 'Kelly Kapoor', 'Customer Relations', 9),
(10, 'Kevin Malone', 'Pastry Chef', 10);

-- --------------------------------------------------------

--
-- Stand-in structure for view `studentdormitorymealplan`
-- (See below for the actual view)
--
CREATE TABLE `studentdormitorymealplan` (
`student_id` int(11)
,`StudentName` varchar(100)
,`DormitoryName` varchar(100)
,`MealPlanType` varchar(50)
,`MealPlanCost` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `studentmealplandetails`
-- (See below for the actual view)
--
CREATE TABLE `studentmealplandetails` (
`student_id` int(11)
,`StudentName` varchar(100)
,`DormitoryName` varchar(100)
,`MealPlanType` varchar(50)
,`MealPlanCost` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `Students`
--

CREATE TABLE `Students` (
  `student_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dormitory_id` int(11) DEFAULT NULL,
  `meal_plan_id` int(11) DEFAULT NULL,
  `dietary_restrictions` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Students`
--

INSERT INTO `Students` (`student_id`, `name`, `dormitory_id`, `meal_plan_id`, `dietary_restrictions`) VALUES
(102, 'Alice Johnson', 1, 3, 'None'),
(103, 'Bob Smith', 2, 2, 'Vegetarian'),
(104, 'Charlie Brown', 3, 3, 'Vegan'),
(105, 'David White', 4, 4, 'Halal'),
(106, 'Emma Davis', 5, 5, 'Kosher'),
(107, 'Frank Martin', 6, 6, 'Gluten-Free'),
(108, 'Grace Lee', 7, 7, 'Keto'),
(109, 'Henry Wilson', 8, 8, 'Paleo'),
(110, 'Isla Robinson', 9, 9, 'Mediterranean'),
(112, 'Alice Johnson', 1, 1, 'None'),
(113, 'Bob Smith', 2, 2, 'Vegetarian'),
(114, 'Charlie Brown', 3, 3, 'Vegan'),
(115, 'David White', 4, 4, 'Halal'),
(116, 'Emma Davis', 5, 5, 'Kosher'),
(117, 'Frank Martin', 6, 6, 'Gluten-Free'),
(118, 'Grace Lee', 7, 7, 'Keto'),
(119, 'Henry Wilson', 8, 8, 'Paleo'),
(120, 'Isla Robinson', 9, 9, 'Mediterranean'),
(122, 'Liam Johnson', 3, 2, 'Vegetarian');

-- --------------------------------------------------------

--
-- Table structure for table `TestTable`
--

CREATE TABLE `TestTable` (
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `TransactionLog`
--

CREATE TABLE `TransactionLog` (
  `log_id` int(11) NOT NULL,
  `food_item` varchar(100) NOT NULL,
  `quantity_changed` int(11) NOT NULL,
  `transaction_type` varchar(50) NOT NULL,
  `transaction_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `TransactionLog`
--

INSERT INTO `TransactionLog` (`log_id`, `food_item`, `quantity_changed`, `transaction_type`, `transaction_date`) VALUES
(1, 'Rice', -20, 'Deduction', '2025-03-16 16:22:24'),
(2, 'Rice', -20, 'Deduction', '2025-03-16 16:25:50'),
(3, 'Rice', -20, 'Deduction', '2025-03-16 16:29:22');

-- --------------------------------------------------------

--
-- Structure for view `dininghallinventory`
--
DROP TABLE IF EXISTS `dininghallinventory`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `student_housing_and_dining_management`.`dininghallinventory`  AS SELECT `d`.`dining_hall_id` AS `dining_hall_id`, `d`.`name` AS `DiningHallName`, `i`.`food_item` AS `food_item`, `i`.`quantity` AS `quantity`, `i`.`expiration_date` AS `expiration_date` FROM (`student_housing_and_dining_management`.`dininghalls` `d` join `student_housing_and_dining_management`.`inventory` `i` on(`d`.`dining_hall_id` = `i`.`dining_hall_id`))  ;

-- --------------------------------------------------------

--
-- Structure for view `dininginventorystatus`
--
DROP TABLE IF EXISTS `dininginventorystatus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `student_housing_and_dining_management`.`dininginventorystatus`  AS SELECT `dh`.`dining_hall_id` AS `dining_hall_id`, `dh`.`name` AS `DiningHallName`, `i`.`food_item` AS `food_item`, `i`.`quantity` AS `quantity`, `i`.`expiration_date` AS `expiration_date` FROM (`student_housing_and_dining_management`.`dininghalls` `dh` join `student_housing_and_dining_management`.`inventory` `i` on(`dh`.`dining_hall_id` = `i`.`dining_hall_id`))  ;

-- --------------------------------------------------------

--
-- Structure for view `studentdormitorymealplan`
--
DROP TABLE IF EXISTS `studentdormitorymealplan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `student_housing_and_dining_management`.`studentdormitorymealplan`  AS SELECT `s`.`student_id` AS `student_id`, `s`.`name` AS `StudentName`, `d`.`name` AS `DormitoryName`, `m`.`type` AS `MealPlanType`, `m`.`cost` AS `MealPlanCost` FROM ((`student_housing_and_dining_management`.`students` `s` join `student_housing_and_dining_management`.`dormitories` `d` on(`s`.`dormitory_id` = `d`.`dormitory_id`)) join `student_housing_and_dining_management`.`mealplans` `m` on(`s`.`meal_plan_id` = `m`.`meal_plan_id`))  ;

-- --------------------------------------------------------

--
-- Structure for view `studentmealplandetails`
--
DROP TABLE IF EXISTS `studentmealplandetails`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `student_housing_and_dining_management`.`studentmealplandetails`  AS SELECT `s`.`student_id` AS `student_id`, `s`.`name` AS `StudentName`, `d`.`name` AS `DormitoryName`, `m`.`type` AS `MealPlanType`, `m`.`cost` AS `MealPlanCost` FROM ((`student_housing_and_dining_management`.`students` `s` join `student_housing_and_dining_management`.`dormitories` `d` on(`s`.`dormitory_id` = `d`.`dormitory_id`)) join `student_housing_and_dining_management`.`mealplans` `m` on(`s`.`meal_plan_id` = `m`.`meal_plan_id`))  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `DietaryRestrictions`
--
ALTER TABLE `DietaryRestrictions`
  ADD PRIMARY KEY (`dietary_id`),
  ADD UNIQUE KEY `restriction_type` (`restriction_type`);

--
-- Indexes for table `DiningHalls`
--
ALTER TABLE `DiningHalls`
  ADD PRIMARY KEY (`dining_hall_id`),
  ADD KEY `idx_dining_hall_id` (`dining_hall_id`);

--
-- Indexes for table `DiningManagers`
--
ALTER TABLE `DiningManagers`
  ADD PRIMARY KEY (`manager_id`),
  ADD KEY `idx_assigned_dining_hall` (`assigned_dining_hall`);

--
-- Indexes for table `Dormitories`
--
ALTER TABLE `Dormitories`
  ADD PRIMARY KEY (`dormitory_id`);

--
-- Indexes for table `FoodSuppliers`
--
ALTER TABLE `FoodSuppliers`
  ADD PRIMARY KEY (`supplier_id`),
  ADD KEY `idx_supplier_id` (`supplier_id`);

--
-- Indexes for table `Inventory`
--
ALTER TABLE `Inventory`
  ADD PRIMARY KEY (`inventory_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `dining_hall_id` (`dining_hall_id`),
  ADD KEY `idx_food_item` (`food_item`);

--
-- Indexes for table `MealPlans`
--
ALTER TABLE `MealPlans`
  ADD PRIMARY KEY (`meal_plan_id`);

--
-- Indexes for table `Roles`
--
ALTER TABLE `Roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `Staff`
--
ALTER TABLE `Staff`
  ADD PRIMARY KEY (`staff_id`),
  ADD KEY `assigned_dining_hall` (`assigned_dining_hall`);

--
-- Indexes for table `Students`
--
ALTER TABLE `Students`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `meal_plan_id` (`meal_plan_id`),
  ADD KEY `idx_student_id` (`student_id`),
  ADD KEY `idx_dormitory_id` (`dormitory_id`);

--
-- Indexes for table `TransactionLog`
--
ALTER TABLE `TransactionLog`
  ADD PRIMARY KEY (`log_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `DietaryRestrictions`
--
ALTER TABLE `DietaryRestrictions`
  MODIFY `dietary_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `DiningHalls`
--
ALTER TABLE `DiningHalls`
  MODIFY `dining_hall_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `DiningManagers`
--
ALTER TABLE `DiningManagers`
  MODIFY `manager_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `Dormitories`
--
ALTER TABLE `Dormitories`
  MODIFY `dormitory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `FoodSuppliers`
--
ALTER TABLE `FoodSuppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `Inventory`
--
ALTER TABLE `Inventory`
  MODIFY `inventory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `MealPlans`
--
ALTER TABLE `MealPlans`
  MODIFY `meal_plan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `Roles`
--
ALTER TABLE `Roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Staff`
--
ALTER TABLE `Staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `Students`
--
ALTER TABLE `Students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `TransactionLog`
--
ALTER TABLE `TransactionLog`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `DiningManagers`
--
ALTER TABLE `DiningManagers`
  ADD CONSTRAINT `diningmanagers_ibfk_1` FOREIGN KEY (`assigned_dining_hall`) REFERENCES `DiningHalls` (`dining_hall_id`) ON DELETE CASCADE;

--
-- Constraints for table `Inventory`
--
ALTER TABLE `Inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `FoodSuppliers` (`supplier_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `inventory_ibfk_2` FOREIGN KEY (`dining_hall_id`) REFERENCES `DiningHalls` (`dining_hall_id`) ON DELETE CASCADE;

--
-- Constraints for table `Staff`
--
ALTER TABLE `Staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`assigned_dining_hall`) REFERENCES `DiningHalls` (`dining_hall_id`) ON DELETE CASCADE;

--
-- Constraints for table `Students`
--
ALTER TABLE `Students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`dormitory_id`) REFERENCES `Dormitories` (`dormitory_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`meal_plan_id`) REFERENCES `MealPlans` (`meal_plan_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
