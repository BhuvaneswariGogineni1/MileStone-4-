import mysql.connector

def fetch_student_data():
    """
    Connects to the database, retrieves student data, and prints it in a structured format.
    Also saves the output to a text file.
    """
    try:
        # Connect to the MySQL database
        conn = mysql.connector.connect(
            host="localhost",
            user="root",     # Replace with your MySQL username
            password="", # Replace with your MySQL password
            database="Student_Housing_and_Dining_Management"
        )

        cursor = conn.cursor()

        # SQL Query to retrieve students data
        query = """
        SELECT student_id, name, dormitory_id, meal_plan_id, dietary_restrictions
        FROM Students
        LIMIT 10;
        """
        cursor.execute(query)
        results = cursor.fetchall()

        # Define file name
        file_name = "student_report.txt"

        # Open the file for writing
        with open(file_name, "w") as file:
            # Header for report
            header = "STUDENT REPORT".center(50, "=")
            file.write(header + "\n\n")
            print(header + "\n")  # Print header on screen

            # Formatting output as a structured text report
            for row in results:
                student_id, name, dormitory_id, meal_plan_id, dietary_restrictions = row
                report_entry = f"""
                Student ID      : {student_id}
                Name           : {name}
                Dormitory ID   : {dormitory_id}
                Meal Plan ID   : {meal_plan_id}
                Dietary Needs  : {dietary_restrictions}
                {'-'*50}
                """
                print(report_entry)  # Print to screen
                file.write(report_entry + "\n")  # Save to file

        print("\nReport generated successfully! Check 'student_report.txt'.")

    except mysql.connector.Error as err:
        print(f"Error: {err}")  # Handle database connection errors

    finally:
        if 'conn' in locals() and conn.is_connected():
            cursor.close()
            conn.close()

# Run the function
fetch_student_data()
